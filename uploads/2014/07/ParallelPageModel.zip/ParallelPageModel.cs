﻿


using System;
using System.Collections.Concurrent;
using System.Dynamic;
using System.Reflection;
using System.Threading.Tasks;


using ImpromptuInterface;

namespace SeleniumDemoTest.PageModels
{
    class ParallelPageModel<TPage>:  DynamicObject
    {
        private readonly TPage[] _pages;
        ParallelPageModel(params TPage[] pages)
        {
            _pages = pages;
        }





        public TPage Cast()
        {
            return this.ActLike();
        }

        public override bool TryInvokeMember(InvokeMemberBinder binder, 
            object[] args, out object result)
        {
            result = null;
            var results = new ConcurrentBag<object>();
            Parallel.ForEach(_pages, page =>
            {
                var thisResult = typeof (TPage).InvokeMember(binder.Name,
                    BindingFlags.InvokeMethod | 
                    BindingFlags.Public | 
                    BindingFlags.Instance, 
                    null, page, args);
                results.Add(thisResult);
            });
            foreach (var thisResult in results)
            {
                // If the return type is the PageModel we are wrapping
                if (thisResult is TPage)
                {
                    result = this;
                }
                else if (result != null)
                {
                    if (!result.Equals(thisResult)) // not the same value
                    {
                        throw new Exception("Call to method returns different values.");
                    }
                }
                else
                {
                    result = thisResult;
                }
            }
            return true;
        }

        public override bool TrySetMember(SetMemberBinder binder, 
            object value)
        {
            Parallel.ForEach(_pages, 
                page => typeof (TPage)
                    .GetProperty(binder.Name)
                    .SetValue(page, value));
            return true;
        }

        public override bool TryGetMember(GetMemberBinder binder, 
            out object result)
        {
            result = null;
            var results = new ConcurrentBag<object>();
            Parallel.ForEach(_pages, page => 
            {
                var thisResult = typeof (TPage)
                    .GetProperty(binder.Name).GetValue(page);
                results.Add(thisResult);
            });

            foreach (var thisResult in results)
            {
                if (thisResult is TPage)
                {
                    result = this;
                }
                else if (result != null)
                {
                    if (!result.Equals(thisResult)) // not the same value
                    {
                      throw new 
                        Exception("Call to property returns different values");
                    }
                }
                else
                {
                    result = thisResult;
                }
            }
        }
    }
}
