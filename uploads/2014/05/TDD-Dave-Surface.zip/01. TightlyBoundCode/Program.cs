﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TightlyCoupledClasses;

namespace _01.TightlyBoundCode
{
    class Program
    {
        static void Main(string[] args)
        {
            var thing1 = new ThingOne();
            thing1.CallThingTwo();
            Console.WriteLine(@"Press any key to continue.");
            Console.ReadKey();
        }
    }
}
