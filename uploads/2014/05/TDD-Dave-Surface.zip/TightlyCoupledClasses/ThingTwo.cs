﻿namespace TightlyCoupledClasses
{
    class ThingTwo
    {
        private readonly ThingOne _thingOne;

        public ThingTwo(ThingOne thingOne)
        {
            _thingOne = thingOne;
            SomeProperty = 0;
        }

        public int SomeProperty { get; set; }

        public void SomeMethodThatUsesThingOne()
        {
            SomeProperty = 2;
            _thingOne.DoSomething();
        }
    }
}
