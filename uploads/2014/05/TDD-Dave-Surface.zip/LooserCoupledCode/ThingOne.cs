﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;

namespace LooserCoupledCode
{
    public class ThingOne : IThingOne
    {
        private readonly IThingTwo _thingTwo;

        public ThingOne()
        {
            var container = RegisterUnity.Unity.GetContainer();
            _thingTwo = container.Resolve<IThingTwo>();
            _thingTwo.ThingOne = this;
        }

        public void DoSomething()
        {
            Console.WriteLine(@"Hello from Thing One!");
            _thingTwo.SomeProperty++;
        }

        public void CallThingTwo()
        {
            _thingTwo.SomeMethodThatUsesThingOne();
        }
    }
}
