namespace LooserCoupledCode
{
    public interface IThingTwo
    {
        int SomeProperty { get; set; }
        IThingOne ThingOne { get;set; }
        void SomeMethodThatUsesThingOne();
    }
}