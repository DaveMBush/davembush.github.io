﻿'Public Module main
'    Public Sub main(ByVal argsFromMain() As String)
'        ' initialization code here

'        If argsFromMain.Length = 0 OrElse argsFromMain(0) <> "/noshow" Then
'            Dim frm As New Form1()
'            frm.Show()
'        End If
'    End Sub
'End Module
