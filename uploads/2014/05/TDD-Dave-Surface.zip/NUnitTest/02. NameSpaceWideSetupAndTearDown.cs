﻿using NUnit.Framework;

namespace NUnitTest
{
    [SetUpFixture] // <-- Designates this class as the namespace setup/teardown class
    public class NameSpaceWideSetupAndTearDown
    {

        [SetUp] // <-- Executes once before all of the test in this namespace
                //     or once before all test in the assembly if this class is
                //     not in any namespace.
        public void SetupForAnyTestInThisNamespaceOrAssembly()
        {
        }

        [TearDown] // <-- Executes once after all of the test in this namespace
                   //     or once after all test in the assembly if this class is
                   //     not in any namespace
        public void TearDownForAnyTestInThisNamespaceOrAssembly()
        {
        }


    }
}