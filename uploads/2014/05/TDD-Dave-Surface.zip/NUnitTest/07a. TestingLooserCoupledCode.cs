﻿using LooserCoupledCode;
using Microsoft.Practices.Unity;
using Moq;
using NUnit.Framework;

namespace NUnitTest
{
    [TestFixture]
    public class WhenSomeMethodThatUsesThingOneIsCalledOnThingTwoUsingLooserCoupling
    {
        private IUnityContainer _container;
        private IThingTwo _thingTwo;
        private Mock<IThingOne> _mockThing1;

        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            _container = RegisterUnity.Unity.GetContainer();
            _mockThing1 = new Mock<IThingOne>();
            _container.RegisterInstance<IThingOne>(_mockThing1.Object);
            _container.RegisterType<IThingTwo, ThingTwo>();
            _thingTwo = _container.Resolve<IThingTwo>();
            _thingTwo.ThingOne = _mockThing1.Object;
            _thingTwo.SomeMethodThatUsesThingOne();
        }

        [Test]
        public void DoSomething_should_be_called()
        {
            _mockThing1.Verify(x => x.DoSomething());
        }

        [Test]
        public void SomeProperty_should_equal_2()
        {
            Assert.That(_thingTwo.SomeProperty, Is.EqualTo(2));
        }

    }
}