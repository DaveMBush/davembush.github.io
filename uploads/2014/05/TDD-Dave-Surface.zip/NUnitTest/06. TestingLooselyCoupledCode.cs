﻿using LooselyCoupledCode;
using Microsoft.Practices.Unity;
using Moq;
using NUnit.Framework;
using RegisterUnity;

namespace NUnitTest
{
    [TestFixture]
    public class WhenSomeMethodThatUsesThingOneIsCalledOnThingTwo
    {
        private IUnityContainer _container;
        private IThingTwo _thingTwo;
        private Mock<IThingOne> _mockThing1;

        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            _container = Unity.GetContainer();
            /////////////////////////////////////
            // For documentation on MOQ, check out 
            // https://github.com/Moq/moq4/wiki/Quickstart
            /////////////////////////////////////
            _mockThing1 = new Mock<IThingOne>();
            _container.RegisterInstance(_mockThing1.Object);
            _container.RegisterType<IThingTwo,ThingTwo>();
            _thingTwo = _container.Resolve<IThingTwo>
                (new ParameterOverride("thingOne",_mockThing1.Object));
            _thingTwo.SomeMethodThatUsesThingOne();
        }

        [Test]
        public void DoSomething_should_be_called()
        {
            _mockThing1.Verify(x => x.DoSomething());
        }

        [Test]
        public void SomeProperty_should_equal_2()
        {
            Assert.That(_thingTwo.SomeProperty, 
                Is.EqualTo(2));            
        }
    }
}
