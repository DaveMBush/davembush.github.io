﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NUnitTest.Helpers
{
    class ReadOnlyContainer
    {
        public int IntBag { get; set; }
    }
}
