﻿using System.Transactions;
using NUnit.Framework;

namespace NUnitTest
{
    [TestFixture]
    public class DatabaseTesting
    {
        private TransactionScope _scope;
        [SetUp]
        public void SetupTest()
        {
            _scope = new TransactionScope();
            // or use regular transaction tracking which may
            // require that you architect your database with
            // transaction tracking in mind to ensure that
            // everything is using the same connection and transaction

            // You may also want to consider creating shadow 
            // tables based on the real tables so that you can 
            // run your test against the shadows and destroy them
            // when the test completes.

            // or you could dump everything and just use tSQLt
            // http://tsqlt.org/ which would be my preferred 
            // primary method even if I used NUnit to drive the test.
            
            // or NDBUnit https://code.google.com/p/ndbunit/
            // which seems to handle everything from the .NET
            // side.

        }

        [TearDown]
        public void TearDownTest()
        {
            _scope.Dispose();
        }

        [Test]
        public void MyTest()
        {
            // Whatever sql you need to execute here.
        }

    }
}