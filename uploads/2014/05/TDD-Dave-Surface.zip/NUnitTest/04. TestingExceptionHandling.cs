﻿// ReSharper disable ConvertToConstant.Local
// ReSharper disable UnusedVariable



using System;
using NUnit.Framework;

namespace NUnitTest
{
    [TestFixture]
    public class TestingExceptionHandling
    {
        [Test]
        [ExpectedException(typeof(DivideByZeroException))]
        public void MyTest()
        {
            var y = 0;
            var x = 1/y;
        }

        [Test]
        // Expected exception must be the exact type that will 
        // be thrown or the test will fail.
        // This test will fail because "DivideByZeroException" is 
        // thown not "Exception"
        [ExpectedException(typeof(Exception))]  
        public void AnotherTest()
        {
            var y = 0;
            var x = 1 / y;
        }

    }
}




// ReSharper restore UnusedVariable
// ReSharper restore ConvertToConstant.Local
