﻿namespace LooselyCoupledCode
{
    public class ThingTwo : IThingTwo
    {
        private IThingOne _thingOne;
        public ThingTwo(IThingOne thingOne)
        {
            _thingOne = thingOne;
            SomeProperty = 0;
        }

        public int SomeProperty { get; set; }

        public void SomeMethodThatUsesThingOne()
        {
            SomeProperty = 2;
            _thingOne.DoSomething();
        }

    }
}
