namespace LooselyCoupledCode
{
    public interface IThingOne
    {
        void DoSomething();
        void CallThingTwo();
    }
}