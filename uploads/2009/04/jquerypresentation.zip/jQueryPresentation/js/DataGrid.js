﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $("table tbody tr:even").addClass("even");
    $("table tbody tr:odd").addClass("odd");
    $("table tbody tr").mouseover(function() {
        $(this).addClass("hover");
    }).mouseout(function() {
        $(this).removeClass("hover");
    });
    $("table tbody tr:last-child").addClass("header").removeClass("even")
        .removeClass("odd").unbind("mouseover").unbind("mouseout");
    $("table tbody tr:first").addClass("header").removeClass("even").removeClass("odd")
        .unbind("mouseover").unbind("mouseout");
}
);