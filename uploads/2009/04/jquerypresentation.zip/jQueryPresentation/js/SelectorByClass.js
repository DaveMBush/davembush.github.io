﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $(".aclass").html("new content for aclass");
}
);

