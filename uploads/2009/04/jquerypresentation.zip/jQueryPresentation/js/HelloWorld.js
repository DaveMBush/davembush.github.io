﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

// the line above gives us intellisense

$(document).ready(
function() {
    alert('Hello World');
}
);

// OR...

$().ready(
function() {
    alert('Hello World 2');
});

// OR...

$(function() {
    alert('Hello World 3');
}
);

// But not exactly the same as
// window.onload()

$(window).bind("load", function() {
    alert('onload');
}
);

