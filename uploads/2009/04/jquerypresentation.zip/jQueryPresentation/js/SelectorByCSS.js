﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $("p.aclass").html("new content for aclass in a paragraph");
    $("p a").html("hyperlink in the paragraph");
}
);

