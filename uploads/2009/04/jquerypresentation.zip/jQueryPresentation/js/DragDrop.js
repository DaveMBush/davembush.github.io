﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $("#moveMe").draggable();
    $("#dropMe").droppable({
        drop: function(ev, ui) {
            alert('dropped');
        }
    });
});

// ev is the event
// ui is the element that was dropped