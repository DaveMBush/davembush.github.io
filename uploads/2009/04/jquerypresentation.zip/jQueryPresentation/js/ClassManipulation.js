﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

// addClass()
// removeClass()
// chaining

$(function() {
    $("p").removeClass("redText").removeClass("font11").addClass("blueText").addClass("font15");
});