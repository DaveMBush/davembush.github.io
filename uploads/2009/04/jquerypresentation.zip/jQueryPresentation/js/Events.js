﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

// bind("event", functionPointer);
// click() fires the click event on the object.
// trigger("event")
// DOES NOT OVERRIDE PREVIOUS bindings.

$(function() {
    $("#clickMe").bind("click", displayMessage);
    $("#clickMe").bind("click", showAlert);
    
    $("#message").bind("click", displayMessageTwo);
}
);

function displayMessage() {
    $("#message").html("You clicked 'Click Me' and I'll click 'Message'").click();
}

function displayMessageTwo() {
    $("#message2").html("Here is another message");
}

function showAlert() {
    alert('you are in showAlert');
}