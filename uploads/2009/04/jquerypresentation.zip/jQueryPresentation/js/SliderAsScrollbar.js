﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $("#slider").slider(
    {   orientation: 'vertical',
        change: handleChange,
        slide: handleSlide,
        min: -100,
        max: 0
    });

    setTimeout(scrollWindow, 1000);
});

function handleChange(e, ui) {
    var maxScroll = $("#scroller")
      .attr("scrollHeight") -
      $("#scroller").height();
    $("#scroller")
      .animate({ scrollTop: -ui.value *
     (maxScroll / 100)
      }, 1000);

}

function handleSlide(e, ui) {
    var maxScroll = $("#scroller")
      .attr("scrollHeight") -
      $("#scroller").height();
    $("#scroller")
      .attr({ scrollTop: -ui.value
        * (maxScroll / 100)
      });

  }

function scrollWindow() {

  var slideValue;
  slideValue = $("#slider").slider("value");
  if (slideValue > -100) {
      $("#slider").slider("value", slideValue - 1);
      setTimeout(scrollWindow, 1000);
  }
}