﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $.ajax({
        type: "POST",
        url: "CallAnASMX_WebServiceWithJSON.asmx/Add",
        data: "{a:20,b:4}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(result) {
            alert(result.d);
        }
    });
});


//A few things that need to be pointed out here:
//
//1.For this to work, type must be “POST.”
//2.url: is the name of the asmx file followed by
//  a slash followed by the name of the web service 
//  method you want to call.
//3.data: is a JSON name/value pair list of all 
//  the parameters in the form of {parametername: parameterValue[,...]}
//  if there are no parameter just use "{}".  Don’t use ""
//  or your code will not work.
//4.contentType and dataType tell jQuery 
//  we are working with JSON.
//5.The function pointed to by success will be called 
//  when the request has finished successfully, it 
//  will pass in a variable of type json.  
//  The d property holds the return value.
//6.If the return value is a structure or 
//  class d will have properties hanging off of it specifying
//  A.type information of the structure or class
//  B.property for each property/variable in the structure or class.