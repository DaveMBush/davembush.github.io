﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    //$("#slider").slider({ orientation: 'vertical' });
    $("#slider").slider({ orientation: 'vertical', range: 'true' ,values: [20,60] });
});
