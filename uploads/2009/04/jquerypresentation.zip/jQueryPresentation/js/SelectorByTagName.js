﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $("a").html("new link label");
}
);

