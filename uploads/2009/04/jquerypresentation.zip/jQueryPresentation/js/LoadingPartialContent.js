﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(function() {
    $("#thing1").bind("click", ThingOne);
    $("#thing2").bind("click", ThingTwo);
});

function ThingOne() {
    $("#contentArea").load("LoadingPartialContent/Thing1.htm");
}

function ThingTwo() {
    $("#contentArea").load("LoadingPartialContent/Thing2.htm");
}
