﻿/// <reference path="jquery-1.3.2-vsdoc2.js" />

$(document).ready(function() {

// Add the div tag that will be the Tooltip dynamically
// This is styled in the CSS to allow absolute positioning and transparency
    $('<div id="tooltip"></div>').appendTo('body');

// Select the div we just added, hide it, and load its innerHtml area with the tooltip shell.
    $('#tooltip').hide().load('PositioningElements/Tooltip.htm');

// Create the function that will display the tooltip and assign it to a 
// variable we will use later
    var showTooltip = function(varText) {
        // Get the upper left corner of the element the mouse is over.
        var eleOffset;
        eleOffset = $(this).offset();
        
        // Retrieve the tooltip
        var eleTooltip = $('#tooltip');
        
        // Load the CENTER of the tooltip with content to display.
        $('#tooltip .toolTipCenter').html('<b><u>Tooltip Title</u></b><br />You can put any html<br />in here you want.');

        // Position the tooltip and make it visible.
        eleTooltip.
           css('left', eleOffset.left - ((eleTooltip.width() - $(this).width()) / 2)).
           css('top', eleOffset.top - eleTooltip.height()).
           show();
    };

// Create the function to hide the tooltip
    var hideTooltip = function() {
        $('#tooltip').hide();
    };

// Wire the functions to the mouseover and mouseout events.
    $('.toolTip').mouseover(showTooltip).mouseout(hideTooltip);

});