﻿using System;

namespace TightlyCoupledClasses
{
    public class ThingOne
    {
        private readonly ThingTwo _thingTwo;

        public ThingOne()
        {
            _thingTwo = new ThingTwo(this);
        }

        public void DoSomething()
        {
            Console.WriteLine(@"Hello from Thing One!");
            _thingTwo.SomeProperty++;
        }

        public void CallThingTwo()
        {
            _thingTwo.SomeMethodThatUsesThingOne();
        }
    }
}
