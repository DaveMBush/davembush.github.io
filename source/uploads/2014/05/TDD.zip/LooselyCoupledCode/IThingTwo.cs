namespace LooselyCoupledCode
{
    public interface IThingTwo
    {
        int SomeProperty { get; set; }
        void SomeMethodThatUsesThingOne();
    }
}