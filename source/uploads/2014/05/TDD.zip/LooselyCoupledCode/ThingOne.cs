﻿using System;
using Microsoft.Practices.Unity;

namespace LooselyCoupledCode
{
    public class ThingOne : IThingOne
    {
        private readonly IThingTwo _thingTwo;

        public ThingOne()
        {
            var container = RegisterUnity.Unity.GetContainer();
            _thingTwo = container.Resolve<IThingTwo>(new ParameterOverride("thingOne",this));
        }

        public void DoSomething()
        {
            Console.WriteLine(@"Hello from Thing One!");
            _thingTwo.SomeProperty++;
        }

        public void CallThingTwo()
        {
            _thingTwo.SomeMethodThatUsesThingOne();
        }
    }
}
