﻿namespace LooserCoupledCode
{
    public class ThingTwo : IThingTwo
    {
        public ThingTwo()
        {
            SomeProperty = 0;
        }

        public int SomeProperty { get; set; }

        public IThingOne ThingOne { set; get; }

        public void SomeMethodThatUsesThingOne()
        {
            SomeProperty = 2;
            if (ThingOne != null) ThingOne.DoSomething();
        }
    }
}
