namespace LooserCoupledCode
{
    public interface IThingOne
    {
        void DoSomething();
        void CallThingTwo();
    }
}