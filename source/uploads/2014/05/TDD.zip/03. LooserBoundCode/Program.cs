﻿using System;
using LooserCoupledCode;
using Microsoft.Practices.Unity;

namespace _03.LooserBoundCode
{
    class Program
    {
        static void Main( )
        {
            var container = RegisterUnity.Unity.GetContainer();

            var thing1 = container.Resolve<ThingOne>();
            thing1.CallThingTwo();
            Console.WriteLine(@"Press any key to continue.");
            Console.ReadKey();

        }
    }
}