﻿using Microsoft.Practices.Unity;

namespace RegisterUnity
{
    public class Unity
    {
        private static IUnityContainer _container;
        public static IUnityContainer GetContainer()
        {
            if (_container != null) return _container;
            _container = new UnityContainer();

            _container.RegisterTypes(
                AllClasses.FromLoadedAssemblies(),
                WithMappings.FromMatchingInterface,
                WithName.Default);
            return _container;

        }
    }
}
