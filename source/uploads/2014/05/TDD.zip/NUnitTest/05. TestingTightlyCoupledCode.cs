﻿using NUnit.Framework;

namespace NUnitTest
{
    [TestFixture]
    public class TestingTightlyCoupledCode
    {
        [SetUp]
        public void SetupTest()
        {
        }

        [TearDown]
        public void TearDownTest()
        {
        }

        [Test]
        public void YouCant()
        {
            // Since the main goal of testing is to test one class
            // at a time, there is no way of testing
            // either ThingOne or ThingTwo without also 
            // running the code from the other class.
            // In fact, while we could fool ourselves into thinking
            // we are testing ThingOne by creating the object, just the
            // fact that we created ThingOne would also create ThingTwo
            // and to verify that the code worked, we'd have to inspect
            // ThingTwo, not ThingOne
            Assert.Inconclusive(@"You can't test tightly coupled code.");
        }

    }
}