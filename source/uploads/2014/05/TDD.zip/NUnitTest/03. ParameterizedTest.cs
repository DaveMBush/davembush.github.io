﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace NUnitTest
{
    [TestFixture]
    public class ParameterizedTest
    {
        [TestCase(4,2, Result = 2)]
        [TestCase(15, 3, Result = 5)]
        public int MyTest(int numerator, int divisor)
        {
            return numerator/divisor;
        }

        [TestCaseSource(sourceName: "TestSource")]
        public int AnotherTest(int numerator, int divisor)
        {
            return numerator/divisor;
        }

        public IEnumerable<TestCaseData> TestSource
        {
            get
            {
                yield return new TestCaseData(4, 2).Returns(2);
                yield return new TestCaseData(15, 5).Returns(3);
                yield return new TestCaseData(1,0).Throws(typeof(DivideByZeroException))
                    .SetName("DivideByZero")
                    .SetDescription("An Exception is expected");
            }
        }

    }
}