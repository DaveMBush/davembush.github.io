﻿using LooserCoupledCode;
using Microsoft.Practices.Unity;
using Moq;
using NUnit.Framework;

namespace NUnitTest
{
    [TestFixture]
    public class WhenDoSomethingIsCalledOnThing1
    {
        private IUnityContainer _container;
        private Mock<IThingTwo> _mockThingTwo;
        private IThingOne _thing1;

        [TestFixtureSetUp]
        public void TestFixtureSetup()
        {
            _container = RegisterUnity.Unity.GetContainer();
            _mockThingTwo = new Mock<IThingTwo>();
            _mockThingTwo.SetupProperty(x => x.SomeProperty);
            _mockThingTwo.Object.SomeProperty = 2;
            _mockThingTwo.SetupProperty(x => x.ThingOne);
            _container.RegisterInstance(_mockThingTwo.Object);
            _container.RegisterType<IThingOne,ThingOne>();
            _thing1 = _container.Resolve<IThingOne>();
            _thing1.DoSomething();
        }

        [Test]
        public void SomeProperty_should_be_incremented_on_ThingTwo()
        {
            _mockThingTwo.VerifySet(x => x.SomeProperty = 3, @"SomeProperty should be incremented on ThingTwo");
        }

    }
}