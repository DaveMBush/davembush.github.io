﻿using NUnit.Framework;
using NUnitTest.Helpers;


namespace NUnitTest
{
    [TestFixture] // <-- Marks the class as a test
    public class Class1
    {
        private readonly ReadOnlyContainer _counter = new ReadOnlyContainer();

        [TestFixtureSetUp] // <-- run once per class
        public void TestFixtureSetup()
        {
            _counter.IntBag = 0;
        }

        [TestFixtureTearDown] // <-- run once at the end of all test in this class
        public void TextFixtureTearDown() { }

        [SetUp] // <-- run before each test
        public void Setup()
        {
            _counter.IntBag++;
        }

        [TearDown] // <-- run after each test
        public void TearDown() { }

        [Test]
        public void Descriptive_test_name()
        {
            // Old style assert
            Assert.Greater(_counter.IntBag, 0, @"IntBag should be greater than 0");
        }

        [Test]
        public void Some_other_descriptive_name()
        {
            // New style assert is easier to understand.
            Assert.That(_counter.IntBag, Is.GreaterThan(0), @"IntBag should be greater than 0");
        }

    }
}
