﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace NUnitTest
{
    public class WhenThisConditionIsMetAndThisActionIsTaken
    {
        [SetUp]
        public void SetUp()
        {
            // All of the code necessary for "Given" precondition.
            // The action that the user is taking.
        }

        [TearDown]
        public void TearDown()
        {
            // any cleanup code goes here.
        }

        [Test]
        public void ThenThisShouldBeTrue()
        {
            // Only the assert to prove the 
            // statement in the method name should go here
            // and only one Assert per Test method.
            Assert.That(1,Is.EqualTo(1));
        }

        [Test]
        public void ThenThisOtherThingShouldBeTrue()
        {
            // Each condition you need to test given the 
            // precondition and action in the SetUp method
            // goes in a separate Test method
            Assert.That(2,Is.EqualTo(2));
        }
    }
}
