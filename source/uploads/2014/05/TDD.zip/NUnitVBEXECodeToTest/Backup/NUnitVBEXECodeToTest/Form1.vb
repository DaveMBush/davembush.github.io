﻿Public Class Form1

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim frm As New Form2
        frm.ShowDialog()
    End Sub
End Class
