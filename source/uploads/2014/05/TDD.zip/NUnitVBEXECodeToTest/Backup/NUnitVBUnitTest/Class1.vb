﻿Imports NUnit.Framework
Imports NUnitVBEXECodeToTest
Imports White.Core
Imports White.Core.Factory
Imports White.Core.UIItems
Imports White.Core.UIItems.Finders
Imports White.Core.UIItems.WindowItems

<TestFixture()> _
Public Class Class1
    Private app As Application
    <SetUp()> Sub Setup()
        app = Application.Launch("NUnitVBEXECodeToTest.EXE")
    End Sub

    <Test()> Sub Test()

        Dim w As Window = app.GetWindow("Form1")
        w.Get(Of Button)("Button1").RaiseClickEvent() ' have to use RaiseClickEvent() instead of Click() because of 64bit
        Dim w2 As Window = w.MessageBox("Form2")
        Assert.True(w2.IsModal)
        w2.Close()

    End Sub

    <TearDown()> Sub TearDown()
        app.Kill()
    End Sub

End Class
