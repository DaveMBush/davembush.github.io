﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using SeleniumDemoTest.Common;


namespace SeleniumDemoTest
{
    [TestFixture(typeof(FirefoxGrid))]
    [TestFixture(typeof(InternetExplorerGrid))]
    public class SeleniumGrid<TDriver> where TDriver : IWebDriver, new()
    {
        private readonly IWebDriver _driver;
        private readonly string _baseUrl;

        public SeleniumGrid()
        {
            _driver = new TDriver();
            _baseUrl = @"http://www.google.com";
        }

        [SetUp]
        public void SetupTest()
        {
        }

        [TearDown]
        public void TearDownTest()
        {
            try
            {
                _driver.Quit();
            }
// ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
        }

        [Test]
        public void MyTest()
        {
            _driver.Navigate().GoToUrl(_baseUrl + "/");
            _driver.FindElement(By.Id("gbqfq")).Clear();
            _driver.FindElement(By.Id("gbqfq")).SendKeys("sql for .net programmers" + Keys.Enter);

            // any time we wait we will wait for 60 seconds.
            var wait = new WebDriverWait(_driver, new TimeSpan(0, 0, 60));

            // now wait for the AJAXy stuff to complete 
            // by checking the title tag
            wait.Until(x => x.Title.ToLower()
                .StartsWith("sql for .net programmers"));

            // now we can check the page for content
            Assert.That(_driver.PageSource, Is.StringContaining("NET Programmer"));
        }

    }
}