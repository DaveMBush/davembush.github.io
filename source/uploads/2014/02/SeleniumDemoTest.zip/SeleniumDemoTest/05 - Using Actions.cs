﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace SeleniumDemoTest
{
    [TestFixture]
    public class UsingActions
    {
        private FirefoxDriver _driver;

        [SetUp]
        public void SetupTest()
        {
            _driver = new FirefoxDriver();
            const string baseURL = "http://jqueryui.com/droppable/";
            _driver.Navigate().GoToUrl(baseURL);
            var wait = new WebDriverWait(_driver, new TimeSpan(0, 0, 60));
            // the demo is in an iframe
            wait.Until(x => x.FindElements(By.ClassName("demo-frame")).Count > 0);
            _driver.SwitchTo().Frame(_driver.FindElement(By.ClassName("demo-frame")));

            // get elements
            wait.Until(x => x.FindElements(By.Id("draggable")).Count > 0);
            var draggable = _driver.FindElement(By.Id("draggable"));
            var droppable = _driver.FindElement(By.Id("droppable"));

            // Do the drag and drop
            var action = new Actions(_driver);
            // Actions are chainable
            // Don't forget .Build().Perform() actions don't fire without them.
            action.DragAndDrop(draggable, droppable).Build().Perform();
            action.MoveToElement(draggable);

        }

        [TearDown]
        public void TearDownTest()
        {
            try
            {
                _driver.Quit();
            }
            // ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
        }

        [Test]
        public void MyTest()
        {
            var droppable = _driver.FindElement(By.Id("droppable"));
            Assert.That(droppable.Text,Is.StringContaining("Dropped"));
        }

    }
}