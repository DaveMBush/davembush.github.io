﻿using System;
using OpenQA.Selenium.Remote;

namespace SeleniumDemoTest.Common
{
    class FirefoxGrid : RemoteWebDriver
    {
        public FirefoxGrid() : base(new Uri("http://localhost:4444/wd/hub"), DesiredCapabilities.Firefox()) { }
    }
}
