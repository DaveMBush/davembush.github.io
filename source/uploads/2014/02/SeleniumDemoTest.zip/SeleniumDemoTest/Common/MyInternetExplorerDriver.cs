﻿using OpenQA.Selenium.IE;

namespace SeleniumDemoTest.Common
{
    class MyInternetExplorerDriver : InternetExplorerDriver
    {
        public MyInternetExplorerDriver()
            : base(@"C:\Selenium")
        {
            
        }
    }
}
