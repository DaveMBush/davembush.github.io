﻿using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace SeleniumDemoTest
{
    [TestFixture]
    public class Clicking
    {
        private FirefoxDriver _driver;

        [SetUp]
        public void SetupTest()
        {
            _driver = new FirefoxDriver();
            const string baseURL = "https://www.google.com/";
            _driver.Navigate().GoToUrl(baseURL);
            _driver.FindElement(By.Id("gbqfq")).Clear();
            _driver.FindElement(By.Id("gbqfq"))
                .SendKeys("sql for .net programmers");

            // using CssSelector just to show another way
            _driver.FindElement(By.CssSelector("#gbqfb")).Click();
            var wait = new WebDriverWait(_driver, new TimeSpan(0, 0, 60));
            wait.Until(x => x.Title.ToLower()
                .StartsWith("sql for .net programmers"));
        }

        [TearDown]
        public void TearDownTest()
        {
            try
            {
                _driver.Quit();
            }
// ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
        }

        [Test]
        public void MyTest()
        {
            Assert.That(_driver.PageSource, Is.StringContaining("NET Programmer"));
        }

    }
}