﻿using System;
using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using SeleniumDemoTest.PageModels;

namespace SeleniumDemoTest
{
    [TestFixture]
    public class UsingPageModel
    {
        private Todo _page;
        [SetUp]
        public void SetupTest()
        {
            _page = new Todo();
            _page.Clear()
                .AddTask("New Task");
        }

        [TearDown]
        public void TearDownTest()
        {
            _page.Close();
        }

        [Test]
        public void MyTest()
        {
            Assert.That(_page.TodoList.First().Text,Is.EqualTo("New Task"));
        }

    }
}