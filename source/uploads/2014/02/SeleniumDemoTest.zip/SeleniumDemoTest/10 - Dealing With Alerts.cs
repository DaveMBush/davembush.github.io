﻿using System;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace SeleniumDemoTest
{
    [TestFixture]
    public class DealingWithAlerts
    {
        private IWebDriver _driver;
        private StringBuilder _verificationErrors;
        private string _baseURL;

        [SetUp]
        public void SetupTest()
        {
            _driver = new FirefoxDriver();
            _baseURL = "http://localhost:18889/HandleAlerts.html";
            _verificationErrors = new StringBuilder();
        }

        [TearDown]
        public void TearDownTest()
        {
            try
            {
                _driver.Quit();
            }
            // ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
            Assert.AreEqual("", _verificationErrors.ToString());
        }

        [Test]
        public void MyTest()
        {
            _driver.Navigate().GoToUrl(_baseURL );
            var alert = _driver.SwitchTo().Alert();
            Assert.That(alert.Text, Is.EqualTo("this is an alert"));
            alert.Accept();
            alert = _driver.SwitchTo().Alert();
            Assert.That(alert.Text,Is.EqualTo("this is a confirmation"));
            alert.Dismiss(); // No button - Accept is "yes" button
            alert = _driver.SwitchTo().Alert();
            alert.SendKeys("Dave");
            alert.Accept();
            alert = _driver.SwitchTo().Alert();
            Assert.That(alert.Text,Is.EqualTo("your name is: Dave"));
        }

    }
}