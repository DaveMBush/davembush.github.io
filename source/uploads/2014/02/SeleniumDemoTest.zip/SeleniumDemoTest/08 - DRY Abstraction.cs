﻿using System.Linq;
using NUnit.Framework;
using OpenQA.Selenium;
using SeleniumDemoTest.DryAbstraction;

namespace SeleniumDemoTest
{
    class DryAbstraction<TDriver> : Test<TDriver> where TDriver : IWebDriver, new()
    {
        public DryAbstraction()
        {
            Page = new Todo(Driver);
            ((Todo) Page).Clear();
        }
        
        [Test]
        public void Test()
        {
            ((Todo)Page).AddTask("New Task");
            Assert.That(((Todo)Page).TodoList.First().Text, Is.EqualTo("New Task"));
            
        }
    }
}
