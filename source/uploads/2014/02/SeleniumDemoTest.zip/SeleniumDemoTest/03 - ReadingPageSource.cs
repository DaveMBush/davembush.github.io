﻿using System;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace SeleniumDemoTest
{
    class ReadingPageSource
    {
        private IWebDriver _driver;
        private StringBuilder _verificationErrors;
        private string _baseURL;


        [SetUp]
        public void SetupTest()
        {
            _driver = new FirefoxDriver();
            _baseURL = "https://www.google.com/";
            _verificationErrors = new StringBuilder();
        }

        [TearDown]
        public void TeardownTest()
        {
            try
            {
                _driver.Quit();
            }
// ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
            Assert.AreEqual("", _verificationErrors.ToString());
        }

        [Test]
        public void TheUntitledTest()
        {
            _driver.Navigate().GoToUrl(_baseURL + "/");
            _driver.FindElement(By.Id("gbqfq")).Clear();
            _driver.FindElement(By.Id("gbqfq"))
                .SendKeys("sql for .net programmers" + Keys.Enter);
            



            // any time we wait we will wait for 60 seconds.
            var wait = new WebDriverWait(_driver, new TimeSpan(0,0,60));

            // now wait for the AJAXy stuff to complete 
            // by checking the title tag
            wait.Until(x => x.Title.ToLower()
                .StartsWith("sql for .net programmers"));
            
            // now we can check the page for content
            Assert.That(_driver.PageSource, Is.StringContaining("NET Programmer"));
        }
    }
}
