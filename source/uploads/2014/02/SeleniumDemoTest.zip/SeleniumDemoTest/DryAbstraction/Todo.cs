﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumDemoTest.Annotations;
using SeleniumDemoTest.PageModels;

namespace SeleniumDemoTest.DryAbstraction
{
    class Todo : Page
    {
        public Todo(IWebDriver driver)
            : base(driver, "http://localhost:18889", "Backbone.js Todos")
        {
            try
            {
                Wait.Until(x => x.PageSource.Contains("items left") || x.PageSource.Contains("item left"));
            }
// ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // there may not be any items.  Ignore catch 
            }
            PageFactory.InitElements(Driver,this);
        }


        [FindsBy(How = How.Id, Using = "new-todo")]
// ReSharper disable once MemberCanBePrivate.Global
        public IWebElement EntryField { get; [UsedImplicitly] set; }

        public List<TodoItem> TodoList
        {
            get
            {
                var elements = Driver.FindElements(By.CssSelector("#todo-list li"));
                return elements.Select(element => new TodoItem(element,Driver)).ToList();
            }
        }

        public void AddTask(string newTask)
        {
            EntryField.Clear();
            EntryField.SendKeys(newTask + Keys.Return);
            Wait.Until(x => TodoList.Any(y => y.Text == newTask));
        }

        public void Clear()
        {
            while (TodoList.Count > 0)
                TodoList[0].Delete();
        }
    }
}
