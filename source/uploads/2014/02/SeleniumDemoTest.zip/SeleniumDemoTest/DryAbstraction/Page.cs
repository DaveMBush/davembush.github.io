﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace SeleniumDemoTest.DryAbstraction
{
    public class Page
    {
        protected IWebDriver Driver { get; set; }
        private string BaseUrl { get; set;}
        public WebDriverWait Wait { get; set; }

        protected Page(IWebDriver driver, string url,string pageTitle)
        {
            Driver = driver;
            BaseUrl = url;
            Wait = new WebDriverWait(driver, new TimeSpan(0,0,60));

            Driver.Navigate().GoToUrl(BaseUrl);
            Wait.Until(x => x.Title.ToLower().StartsWith(pageTitle.ToLower()));
        }
    }
}
