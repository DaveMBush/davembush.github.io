﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using SeleniumDemoTest.Common;

namespace SeleniumDemoTest.DryAbstraction
{
    [TestFixture(typeof(FirefoxDriver))]
    [TestFixture(typeof(MyInternetExplorerDriver))]
    public class Test<TDriver> where TDriver : IWebDriver, new()
    {
        protected IWebDriver Driver { get; set; }
        protected Page Page { get; set; }

        public Test()
        {
            Driver = new TDriver();
        }
        
        [TearDown]
        public virtual void TearDown()
        {
            Driver.Quit();
        }

    }
}