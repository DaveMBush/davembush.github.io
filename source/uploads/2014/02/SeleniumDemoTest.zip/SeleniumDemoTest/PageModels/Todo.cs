﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.PageObjects;
using SeleniumDemoTest.Annotations;

namespace SeleniumDemoTest.PageModels
{
    class Todo
    {
        private readonly IWebDriver _driver;
        private const string BaseUrl = "http://localhost:18889";

        public Todo()
        {
            _driver = new FirefoxDriver();
            _driver.Navigate().GoToUrl(BaseUrl);

            // registers the FindsBy attributed properties
            PageFactory.InitElements(_driver, this);

        }

        public Todo Close()
        {
            try
            {
                _driver.Quit();
            }
// ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
            }
            return this;
        }

        [FindsBy(How = How.Id, Using = "new-todo")]
        private IWebElement EntryField { get; [UsedImplicitly] set; }

        public List<TodoItem> TodoList
        {
            get
            {
                var elements = _driver.FindElements(By.CssSelector("#todo-list li"));
                return elements.Select(element => new TodoItem(element,_driver)).ToList();
            }
        }

        public Todo AddTask(string newTask)
        {
            EntryField.Clear();
            EntryField.SendKeys(newTask + Keys.Enter);
            return this;
        }

        public Todo Clear()
        {
            while(TodoList.Count > 0)
                TodoList[0].Delete();
            return this;
        }
    }
}
