﻿using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;

namespace SeleniumDemoTest.PageModels
{
    class TodoItem
    {
        private readonly IWebElement _item;
        private readonly IWebDriver _driver;
        public TodoItem(IWebElement item, IWebDriver driver)
        {
            _driver = driver;
            _item = item;
        }

        public IWebElement CheckBox
        {
            get
            {
                return _item.FindElement(By.ClassName("toggle"));
            }
        }

        public string Text
        {
            get
            {
                return _item.Text.Trim();
            }
        }

        public IWebElement EditField
        {
            get
            {
                return _item.FindElement(By.ClassName("edit"));
            }
        }

        public void Delete()
        {
            var action = new Actions(_driver);
            action.MoveToElement(_item).MoveToElement(_item.FindElement(By.ClassName("destroy"))).Click().Build().Perform();
        }
    }
}
