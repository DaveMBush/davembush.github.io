﻿using System;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;

namespace SeleniumDemoTest
{
    [TestFixture]
    public class ExecutingJavaScript
    {
        private IWebDriver _driver;
        private StringBuilder _verificationErrors;
        private string _baseURL;

        [SetUp]
        public void SetupTest()
        {
            _driver = new FirefoxDriver();
            _baseURL = "https://www.google.com/";
            _verificationErrors = new StringBuilder();
        }

        [TearDown]
        public void TeardownTest()
        {
            try
            {
                _driver.Quit();
            }
            // ReSharper disable once EmptyGeneralCatchClause
            catch (Exception)
            {
                // Ignore errors if unable to close the browser
            }
            Assert.AreEqual("", _verificationErrors.ToString());
        }

        [Test]
        public void TheUntitledTest()
        {
            _driver.Navigate().GoToUrl(_baseURL + "/");

            // insert a javascript alert()
            ((IJavaScriptExecutor) _driver).ExecuteScript("alert('this is a message from selenium');");




        }

        [TearDown]
        public void TearDownTest()
        {
        }



    }
}