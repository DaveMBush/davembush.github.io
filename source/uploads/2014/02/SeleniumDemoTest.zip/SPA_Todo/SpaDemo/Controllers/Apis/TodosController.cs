﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SpaDemo.Models;

namespace SpaDemo.Controllers.Apis
{
    public class TodosController : ApiController
    {
        private readonly SpaDemoContext _db = new SpaDemoContext();

        // GET api/Default1
        public IEnumerable<Todo> GetTodoes()
        {
            return _db.Todoes.AsEnumerable();
        }

        // GET api/Default1/5
        public Todo GetTodo(int id)
        {
            Todo todo = _db.Todoes.Find(id);
            if (todo == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }

            return todo;
        }

        // PUT api/Default1/5
        public HttpResponseMessage PutTodo(int id, Todo todo)
        {
            if (!ModelState.IsValid || id != todo.Id) return Request.CreateResponse(HttpStatusCode.BadRequest);
            _db.Entry(todo).State = EntityState.Modified;

            try
            {
                _db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK);
        }

        // POST api/Default1
        public HttpResponseMessage PostTodo(Todo todo)
        {
            if (!ModelState.IsValid) return Request.CreateResponse(HttpStatusCode.BadRequest);
            _db.Todoes.Add(todo);
            _db.SaveChanges();

            var response = Request.CreateResponse(HttpStatusCode.Created, todo);
            if (Url != null && todo != null && response != null) 
                response.Headers.Location = new Uri(Url.Link("DefaultApi", new { id = todo.Id }));
            return response;
        }

        // DELETE api/Default1/5
        public HttpResponseMessage DeleteTodo(int id)
        {
            var todo = _db.Todoes.Find(id);
            if (todo == null)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            _db.Todoes.Remove(todo);

            try
            {
                _db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return Request.CreateResponse(HttpStatusCode.NotFound);
            }

            return Request.CreateResponse(HttpStatusCode.OK, todo);
        }

        public void DeleteAll()
        {
            foreach (Todo item in GetTodoes())
            {
                DeleteTodo(item.Id);
            }
        }

        protected override void Dispose(bool disposing)
        {
            _db.Dispose();
            base.Dispose(disposing);
        }
    }
}